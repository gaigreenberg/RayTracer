package RayTracing;

public enum Shapes {

    Sphere,
    Plane,
    Box
}
