package RayTracing;

public abstract class Shape {
}
