package RayTracing;

public class Camera {
    public Vector Position;
    public Vector LookAtPoint;
    public Vector UpVector;
    public double ScreenDistance;
    public double ScreenWidth;
    public double K;

}
